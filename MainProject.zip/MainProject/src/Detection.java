public class Detection {
}
